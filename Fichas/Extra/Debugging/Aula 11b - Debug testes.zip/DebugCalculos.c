#include <stdio.h>

void le_dados(int *a, int *b) {
	printf("a = ");
	scanf("%d", a);

	printf("b = ");
	scanf("%d", b);
}

int calcula_resultado(int a, int b) {
	return a + b;
}

void escreve_resultado(int s) {
	printf("Resultado = %d\n", s);
}

main(){
	int num1, num2, soma;

	le_dados(&num1, &num2);
	soma = calcula_resultado(num1, num2);
	escreve_resultado(soma);
}
